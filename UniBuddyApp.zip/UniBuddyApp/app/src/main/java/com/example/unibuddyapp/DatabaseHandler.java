package com.example.unibuddyapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHandler extends SQLiteOpenHelper {

    //Database version
    private static final int DATABASE_VERSION = 1;

    //Database Name
    private static final String DATABASE_NAME = "unibuddy.db";

    //Table Name
    private static final String TABLE_NAME = "modules";

    //Table fields
    private static final String COLUMN_MODULE = "module";
    private static final String COLUMN_HOURS = "hours";
    private static final String COLUMN_DAY = "day";
    private static final String COLUMN_DATE = "date";

    //Events table
    private static final String EVENT_TABLE_NAME = "events";
    //Events table fields
    private static final String MODULE = "module";
    private static final String TIME = "time";
    private static final String DATE = "date";




    SQLiteDatabase database;

    public <context> DatabaseHandler(@Nullable Context context) {
        super((Context) context, DATABASE_NAME, null, DATABASE_VERSION);
        database = getWritableDatabase();
    }

    @Override
    //create the module and events tables
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " ( " + COLUMN_MODULE + " TEXT, "
                + COLUMN_HOURS +
                " TEXT, "
                + COLUMN_DAY +
                " TEXT, "
                + COLUMN_DATE +" TEXT )");
        db.execSQL("CREATE TABLE " + EVENT_TABLE_NAME + " ( " + MODULE + " TEXT, "
                + TIME +
                " TEXT, "
                + DATE +
                " TEXT )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + EVENT_TABLE_NAME);
        onCreate(db);
    }

    //add a module to the database

    public boolean addModuleToDatabase(String module, String hours, String day, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues entry = new ContentValues();
        entry.put("module",module);
        entry.put("hours",hours);
        entry.put("day",day);
        entry.put("date",date);
        long result = db.insert(TABLE_NAME.toString(),null,entry);
        if (result==-1){
            return false;
        }
        else return true;
    }

    //add an event to the database
    public boolean addEventToDatabase (String module, String time, String date){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues entry = new ContentValues();
        entry.put("module",module);
        entry.put("time",time);
        entry.put("date",date);
        long result = db.insert(EVENT_TABLE_NAME.toString(),null,entry);
        if (result==-1){
            return false;
        }
        else return true;

    }

    //read an event from the database

    public Cursor ReadEvents(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from "+EVENT_TABLE_NAME, null);
        return cursor;

    }

}

