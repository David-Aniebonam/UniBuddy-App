package com.example.unibuddyapp;

import java.util.ArrayList;
import java.util.Collections;

public class revisionPlan {
    //ArrayList<String> Declaration
    private static ArrayList<String> modules = new ArrayList<String>();
    private static ArrayList<String> hours = new ArrayList<String>();
    private static ArrayList<String> days = new ArrayList<String>();

//add module to a plan
    public static void addModule(String moduleName, String revisionHours, String revisionDay){
        modules.add(moduleName.toLowerCase());
        hours.add(revisionHours);
        days.add(getDay(revisionDay));
    }
    //output lists of modules. used for testing purposes
    public static void outputLists(){
        System.out.println(modules);
        System.out.println(hours);
        System.out.println(days);
    }
    //assigning and hour to each module
    public static void assignHours(){
        for(int i = 0;i<modules.size();i++) {
            planCreator.assignModules(days.get(i), modules.get(i), hours.get(i));
        }
    }

//getting the day of revision for each added module
    public static String getDay(String revisionDay){
        String day;
        if(revisionDay.toLowerCase().contains("any")){
            day = leastFrequentDay();
        }
        else day = revisionDay.toLowerCase();
        return day;
    }

    public static ArrayList getModules(){
        return revisionPlan.modules;
    }
    public static ArrayList getHours(){
        return hours;
    }
    public static ArrayList getDays(){
        return revisionPlan.days;
    }
    public static void resetLists(){
        modules.clear();
        hours.clear();
        days.clear();

//setting revision day as the one with the least sessions if user does not specific a day.
    }
    static String leastFrequentDay() {
        // Sort the array
        ArrayList<String> arr = days;
        Collections.sort(arr);
        int n = arr.size();
        // find the min frequency using
        // linear traversal
        int min_count = n+1;
        String res = "-1";
        int curr_count = 1;

        for (int i = 1; i < n; i++) {
            if (arr.get(i) == arr.get(i - 1))
                curr_count++;
            else {
                if (curr_count < min_count) {
                    min_count = curr_count;
                    res = arr.get(i - 1);
                }
                curr_count = 1;
            }
        }
        // If last element is least frequent
        if (curr_count < min_count)
        {
            min_count = curr_count;
            res = arr.get(n - 1);
        }
        return res;
    }





}
