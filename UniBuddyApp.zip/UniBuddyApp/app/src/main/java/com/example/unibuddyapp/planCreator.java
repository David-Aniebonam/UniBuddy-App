package com.example.unibuddyapp;

import java.util.ArrayList;
import java.util.Arrays;

public class planCreator {
    public static ArrayList<Integer> daySlots = new ArrayList<Integer>(
            Arrays.asList(8,9,10,11,13,14,15,17,18,19)
    );
    //the revision sessions assigned to each day
    public static ArrayList mondaySlots = new ArrayList();
    public static ArrayList tuesdaySlots = new ArrayList();
    public static ArrayList wednesdaySlots = new ArrayList();
    public static ArrayList thursdaySlots = new ArrayList();
    public static ArrayList fridaySlots = new ArrayList();
//add a module to a days revision session slots
    public static void assignModules(String day, String module, String hours) {

        if (day.contentEquals("monday") && mondaySlots.size() < 10) {
            for (int i = 0; i < Integer.parseInt(hours); i++)
                mondaySlots.add(module);
        }
        if (day.contentEquals("tuesday") && tuesdaySlots.size() < 10) {
            for (int i = 0; i < Integer.parseInt(hours); i++)
                tuesdaySlots.add(module);
        }
        if (day.contentEquals("wednesday") && wednesdaySlots.size() < 10) {
            for (int i = 0; i < Integer.parseInt(hours); i++)
                wednesdaySlots.add(module);
        }
        if (day.contentEquals("thursday") && thursdaySlots.size() < 10) {
            for (int i = 0; i < Integer.parseInt(hours); i++)
                thursdaySlots.add(module);
        }
        if (day.contentEquals("friday") && fridaySlots.size() < 10) {
            for (int i = 0; i < Integer.parseInt(hours); i++)
                fridaySlots.add(module);
        }




    }

}
