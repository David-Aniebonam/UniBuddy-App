package com.example.unibuddyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class createPlanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        revisionPlan.resetLists();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_plan);
        //connect to the database
        final DatabaseHandler db = new DatabaseHandler(this);
        db.onUpgrade(db.database,1,2);

        //code to go to the homepage

        ImageButton homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent homepageIntent = new Intent(createPlanActivity.this,homepageActivity.class);
                startActivity(homepageIntent);
            }
        });

        //code to go to the web guide

        ImageButton helpButton = findViewById(R.id.helpButton);
        helpButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent helpIntent = new Intent(createPlanActivity.this,helpActivity.class);
                startActivity(helpIntent);
            }
        });

        //adding a module to the plan
        final LinearLayout container = (LinearLayout)findViewById(R.id.moduleCard);
        ImageButton addButton = findViewById(R.id.addButton);
        addButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                TextView moduleName= findViewById(R.id.moduleName);
                TextView revisionHours= findViewById(R.id.revisionHours);
                TextView revisionDay= findViewById(R.id.revisionDay);
                if(moduleName.getText().toString().contentEquals("")||revisionHours.getText().toString().contentEquals("")){
                    Toast.makeText(getApplicationContext(), "Missing Information!", Toast.LENGTH_SHORT).show();
                }
                else {
                    String entry = " Module: " + moduleName.getText() + " | Hours : " + revisionHours.getText() + " | Day: " + revisionDay.getText();
                    TextView newModule = new TextView(createPlanActivity.this); //Creating new TextView
                    newModule.setText(entry);    //Setting attribute
                    container.addView(newModule);    //Adding it to the container
                    revisionPlan.addModule(moduleName.getText().toString(), revisionHours.getText().toString(), revisionDay.getText().toString());
                    Toast.makeText(getApplicationContext(), "Module Added!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //creating a plan from the added modules

        ImageButton createButton = findViewById(R.id.createButton);
        createButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                ArrayList modulesList = revisionPlan.getModules();
                ArrayList hoursList = revisionPlan.getHours();
                ArrayList daysList = revisionPlan.getDays();
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
                Date date = new Date();

                for(int i =0; i<modulesList.size();i++){
                    boolean insert = db.addModuleToDatabase(modulesList.get(i).toString(),hoursList.get(i).toString(),
                            daysList.get(i).toString(),date.toString());
                    if (insert==true){
                        System.out.println("Successfully added to database");

                    }
                }
                //call the page to view the plan
                revisionPlan.assignHours();
                Intent revisionPageIntent = new Intent(createPlanActivity.this,revisionPageActivity.class);
                startActivity(revisionPageIntent);


            }
        });
    }
}
