package com.example.unibuddyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class homepageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        //button to go to create plan page

        ImageButton createPlanButton = findViewById(R.id.createPlanButton);
        createPlanButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent createPageIntent = new Intent(homepageActivity.this,createPlanActivity.class);
                startActivity(createPageIntent);
            }
        });

        //button to to go help page

        ImageButton helpButton = findViewById(R.id.helpButton);
        helpButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent helpIntent = new Intent(homepageActivity.this,helpActivity.class);
                startActivity(helpIntent);
            }
        });

        //button to go to update plan page
        ImageButton updatePlanButton = findViewById(R.id.updatePlanButton);
        updatePlanButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent updatePageIntent = new Intent(homepageActivity.this,updatePlanActivity.class);
                startActivity(updatePageIntent);
            }
        });
    }
}
