package com.example.unibuddyapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class mondayFragment extends Fragment {

    public mondayFragment() {
        // Required empty public constructor
    }
//view of revision plans for given day

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_monday, container, false);
        ArrayList <String> modules=planCreator.mondaySlots;
        for(int i =0;i<modules.size();i++){
            TextView slot;
                 if(i==0) {
                     slot = (TextView) rootView.findViewById(R.id.eight);
                     slot.setText(modules.get(i));
                 }
                if(i==1) {
                    slot = (TextView) rootView.findViewById(R.id.nine);
                    slot.setText(modules.get(i));
                }
                if(i==2) {
                    slot = (TextView) rootView.findViewById(R.id.ten);
                    slot.setText(modules.get(i));
                }
                if(i==3) {
                    slot = (TextView) rootView.findViewById(R.id.eleven);
                    slot.setText(modules.get(i));
                }
                if(i==4) {
                    slot = (TextView) rootView.findViewById(R.id.one);
                    slot.setText(modules.get(i));
                }
                if(i==5) {
                    slot = (TextView) rootView.findViewById(R.id.two);
                    slot.setText(modules.get(i));
                }
                if(i==6) {
                    slot = (TextView) rootView.findViewById(R.id.three);
                    slot.setText(modules.get(i));
                }
                if(i==7) {
                    slot = (TextView) rootView.findViewById(R.id.five);
                    slot.setText(modules.get(i));
                }
                if(i==8) {
                    slot = (TextView) rootView.findViewById(R.id.six);
                    slot.setText(modules.get(i));
                }
                if(i==9) {
                    slot = (TextView) rootView.findViewById(R.id.seven);
                    slot.setText(modules.get(i));
                }
            }

        return rootView;
    }


}
