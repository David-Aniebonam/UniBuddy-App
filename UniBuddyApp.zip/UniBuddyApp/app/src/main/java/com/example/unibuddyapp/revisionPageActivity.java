package com.example.unibuddyapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.app.ActionBar;
import android.app.AlarmManager;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ShareActionProvider;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;


import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class revisionPageActivity extends AppCompatActivity {
    ViewPager pager;
    TabLayout mTabLayout;
    TabItem monday, tuesday, wednesday, thursday, friday;
    PagerAdapter adapter;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_revision_page);
        final DatabaseHandler db = new DatabaseHandler(this);
        Cursor cursor = db.ReadEvents();


        pager = findViewById(R.id.viewpager);
        mTabLayout = findViewById(R.id.tablayout);
        monday = findViewById(R.id.mondayTab);
        tuesday = findViewById(R.id.tuesdayTab);
        wednesday = findViewById(R.id.wednesdayTab);
        thursday = findViewById(R.id.thursdayTab);
        friday = findViewById(R.id.fridayTab);

        adapter = new PagerAdapter(getSupportFragmentManager(),
                FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT, mTabLayout.getTabCount());
        pager.setAdapter(adapter);

        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                pager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        pager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabLayout));


//button to go back to homepage
        ImageButton homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent homepageIntent = new Intent(revisionPageActivity.this,homepageActivity.class);
                startActivity(homepageIntent);
            }
        });
//button to go to help page
        ImageButton helpButton = findViewById(R.id.helpButton);
        helpButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent helpIntent = new Intent(revisionPageActivity.this,helpActivity.class);
                startActivity(helpIntent);
            }
        });
//button to go to update plan page
        Button updateButton = findViewById(R.id.updateButton);
        updateButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

//date format
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH);
                Date date = new Date();
                //lists of the alarms to be set on a given day
                ArrayList<Integer> mondayAlarm= new ArrayList<Integer>();
                ArrayList<Integer> tuesdayAlarm= new ArrayList<Integer>();
                ArrayList<Integer> wednesdayAlarm= new ArrayList<Integer>();
                ArrayList<Integer> thursdayAlarm= new ArrayList<Integer>();
                ArrayList<Integer> fridayAlarm= new ArrayList<Integer>();
                //adding the days of the week for the possible alarms to the calendar
                Calendar c1 = Calendar.getInstance(Locale.ENGLISH);
                c1.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                mondayAlarm.add(Calendar.MONDAY);
                tuesdayAlarm.add(Calendar.TUESDAY);
                wednesdayAlarm.add(Calendar.WEDNESDAY);
                thursdayAlarm.add(Calendar.THURSDAY);
                fridayAlarm.add(Calendar.FRIDAY);
                //setting the dates for each of the days as strings
                String mondayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String tuesdayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String wednesdayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String thursdayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String fridayDate = dateFormat.format(c1.getTime());
                //adding revision sessions as events to db and alarm lists
                for(int i=0;i<planCreator.mondaySlots.size();i++){
                    String moduleName = (String) planCreator.mondaySlots.get(i);
                    String moduleTime = planCreator.daySlots.get(i).toString();
                    db.addEventToDatabase(moduleName, moduleTime, mondayDate);
                }
                for(int i=0;i<planCreator.tuesdaySlots.size();i++){
                    String moduleName = (String) planCreator.tuesdaySlots.get(i);
                    String moduleTime = planCreator.daySlots.get(i).toString();
                    db.addEventToDatabase(moduleName, moduleTime, tuesdayDate);
                }
                for(int i=0;i<planCreator.wednesdaySlots.size();i++){
                    String moduleName = (String) planCreator.wednesdaySlots.get(i);
                    String moduleTime = planCreator.daySlots.get(i).toString();
                    db.addEventToDatabase(moduleName, moduleTime, wednesdayDate);
                }
                for(int i=0;i<planCreator.thursdaySlots.size();i++){
                    String moduleName = (String) planCreator.thursdaySlots.get(i);
                    String moduleTime = planCreator.daySlots.get(i).toString();
                    db.addEventToDatabase(moduleName, moduleTime, thursdayDate);
                }
                for(int i=0;i<planCreator.fridaySlots.size();i++){
                    String moduleName = (String) planCreator.fridaySlots.get(i);
                    String moduleTime = planCreator.daySlots.get(i).toString();
                    db.addEventToDatabase(moduleName, moduleTime, fridayDate);
                }
                Intent homepageIntent = new Intent(revisionPageActivity.this,homepageActivity.class);
                startActivity(homepageIntent);
                //setting the alarms for each of the days
                ArrayList<String> moduleNames= new ArrayList<String>();
                ArrayList<String> moduleHours= new ArrayList<String>();
                ArrayList<String> moduleDates= new ArrayList<String>();
                while(cursor.moveToNext()){
                    moduleNames.add(cursor.getString(0));
                    moduleHours.add(cursor.getString(1));
                    moduleDates.add(cursor.getString(2));
                }
                for(int i=0;i<moduleNames.size();i++){
                    if(moduleDates.get(i).contentEquals(mondayDate)){
                        String moduleHour = moduleHours.get(i);
                        String moduleName = moduleNames.get(i);
                        int hour = Integer.parseInt(moduleHour);
                        Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                        alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                        alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, mondayAlarm);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);

                        startActivity(alarmIntent);

                    }
                    if(moduleDates.get(i).contentEquals(tuesdayDate)){
                        String moduleHour = moduleHours.get(i);
                        String moduleName = moduleNames.get(i);
                        int hour = Integer.parseInt(moduleHour);
                        Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                        alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                        alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, tuesdayAlarm);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                        startActivity(alarmIntent);

                    }
                    if(moduleDates.get(i).contentEquals(wednesdayDate)){
                        String moduleHour = moduleHours.get(i);
                        String moduleName = moduleNames.get(i);
                        int hour = Integer.parseInt(moduleHour);
                        Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                        alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                        alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, wednesdayAlarm);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                        startActivity(alarmIntent);

                    }
                    if(moduleDates.get(i).contentEquals(thursdayDate)){
                        String moduleHour = moduleHours.get(i);
                        String moduleName = moduleNames.get(i);
                        int hour = Integer.parseInt(moduleHour);
                        Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                        alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                        alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, thursdayAlarm);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                        startActivity(alarmIntent);

                    }
                    if(moduleDates.get(i).contentEquals(fridayDate)){
                        String moduleHour = moduleHours.get(i);
                        String moduleName = moduleNames.get(i);
                        int hour = Integer.parseInt(moduleHour);
                        Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                        alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                        alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, fridayAlarm);
                        alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                        startActivity(alarmIntent);

                    }


                }
                //starting notification service
                startService(new Intent(getBaseContext(), MyService.class));

            }
        });
    }



}
