package com.example.unibuddyapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.Calendar;
//revision day notification service
public class MyService extends Service {

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId){
        //get the revision sessions for each day
        ArrayList mondayList = planCreator.mondaySlots;
        ArrayList tuesdayList = planCreator.tuesdaySlots;
        ArrayList wednesdayList = planCreator.wednesdaySlots;
        ArrayList thursdayList = planCreator.thursdaySlots;
        ArrayList fridayList = planCreator.fridaySlots;
        Toast.makeText(this, "Service has started", Toast.LENGTH_SHORT).show();
        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE) ;
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR_OF_DAY, 7);
        //To display the notification
        Intent notificationIntent = new Intent("android.media.action.DISPLAY_NOTIFICATION");
        notificationIntent.addCategory("android.intent.category.DEFAULT");
        PendingIntent broadcast = PendingIntent.getBroadcast(this, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        int day = calendar.get(Calendar.DAY_OF_WEEK);
        //checks if there is a revision session on the current day
        switch (day) {
            case Calendar.MONDAY:
                if (mondayList.size()>0){
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), broadcast);


                }
                // Current day is Sunday
                break;
            case Calendar.TUESDAY:
                if (tuesdayList.size()>0){
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), broadcast);


                }

                // Current day is Monday
                break;
            case Calendar.WEDNESDAY:
                if (wednesdayList.size()>0){
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), broadcast);


                }
                // etc.
                break;
            case Calendar.THURSDAY:
                if (thursdayList.size()>0){
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), broadcast);


                }
                // etc.
                break;
            case Calendar.FRIDAY:
                if (fridayList.size()>0){
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), broadcast);


                }
                // etc.
                break;
        }
        return START_STICKY;
    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        Toast.makeText(this, "Service has ended", Toast.LENGTH_SHORT).show();

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}
