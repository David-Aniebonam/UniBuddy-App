package com.example.unibuddyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final DatabaseHandler db = new DatabaseHandler(this);

        //button to login and check users permissions

        Button loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView username= findViewById(R.id.username);
                TextView password= findViewById(R.id.password);
                if(username.getText().toString().contentEquals("eee")&&password.getText().toString().contentEquals("eee")){
                    Intent homepageIntent = new Intent(MainActivity.this,homepageActivity.class);
                    Toast.makeText(getApplicationContext(), "Successfully Logged In!", Toast.LENGTH_SHORT).show();
                    startActivity(homepageIntent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "Incorrect Username or Password!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
