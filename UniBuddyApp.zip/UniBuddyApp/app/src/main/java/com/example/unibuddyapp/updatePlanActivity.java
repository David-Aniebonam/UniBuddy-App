package com.example.unibuddyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class updatePlanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_plan);
        final DatabaseHandler db = new DatabaseHandler(this);
        Cursor cursor = db.ReadEvents();
//button to go to homepage
        ImageButton homeButton = findViewById(R.id.homeButton);
        homeButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent homepageIntent = new Intent(updatePlanActivity.this,homepageActivity.class);
                startActivity(homepageIntent);
            }
        });
//button to go to help page
        ImageButton helpButton = findViewById(R.id.helpButton);
        helpButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent helpIntent = new Intent(updatePlanActivity.this,helpActivity.class);
                startActivity(helpIntent);
            }
        });
//button to add a new session to plan
        ImageButton addButton = findViewById(R.id.addSessionButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView module = findViewById(R.id.module);
                TextView time = findViewById(R.id.time);
                TextView day = findViewById(R.id.day);


                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH);
                Date date = new Date();
                //lists of the alarms to be set on a given day
                ArrayList<Integer> mondayAlarm = new ArrayList<Integer>();
                ArrayList<Integer> tuesdayAlarm = new ArrayList<Integer>();
                ArrayList<Integer> wednesdayAlarm = new ArrayList<Integer>();
                ArrayList<Integer> thursdayAlarm = new ArrayList<Integer>();
                ArrayList<Integer> fridayAlarm = new ArrayList<Integer>();
                //adding the days of the week for the possible alarms to the calendar
                Calendar c1 = Calendar.getInstance(Locale.ENGLISH);
                c1.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                mondayAlarm.add(Calendar.MONDAY);
                tuesdayAlarm.add(Calendar.TUESDAY);
                wednesdayAlarm.add(Calendar.WEDNESDAY);
                thursdayAlarm.add(Calendar.THURSDAY);
                fridayAlarm.add(Calendar.FRIDAY);
                //setting the dates for each of the days as strings
                String mondayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String tuesdayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String wednesdayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String thursdayDate = dateFormat.format(c1.getTime());
                c1.add(Calendar.DATE, 1);
                String fridayDate = dateFormat.format(c1.getTime());
//adding revision session as event to db and alarm list
                if(day.getText().toString().toLowerCase().contentEquals("monday")){
                    String moduleHour = time.getText().toString();
                    String moduleName = module.getText().toString();
                    int hour = Integer.parseInt(moduleHour);
                    db.addEventToDatabase(moduleName, moduleHour, mondayDate);
                    Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                    alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, mondayAlarm);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                    Toast.makeText(getApplicationContext(), "Session: "+moduleName+" added on "+day.getText().toString(), Toast.LENGTH_SHORT).show();
                    startActivity(alarmIntent);
                }
                if(day.getText().toString().toLowerCase().contentEquals("tuesday")){
                    String moduleHour = time.getText().toString();
                    String moduleName = module.getText().toString();
                    int hour = Integer.parseInt(moduleHour);
                    db.addEventToDatabase(moduleName, moduleHour, tuesdayDate);
                    Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                    alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, tuesdayAlarm);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                    Toast.makeText(getApplicationContext(), "Session: "+moduleName+" added on "+day.getText().toString(), Toast.LENGTH_SHORT).show();
                    startActivity(alarmIntent);

                }
                if(day.getText().toString().toLowerCase().contentEquals("wednesday")){
                    String moduleHour = time.getText().toString();
                    String moduleName = module.getText().toString();
                    int hour = Integer.parseInt(moduleHour);
                    db.addEventToDatabase(moduleName, moduleHour, wednesdayDate);
                    Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                    alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, wednesdayAlarm);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                    Toast.makeText(getApplicationContext(), "Session: "+moduleName+" added on "+day.getText().toString(), Toast.LENGTH_SHORT).show();
                    startActivity(alarmIntent);

                }
                if(day.getText().toString().toLowerCase().contentEquals("thursday")){
                    String moduleHour = time.getText().toString();
                    String moduleName = module.getText().toString();
                    int hour = Integer.parseInt(moduleHour);
                    db.addEventToDatabase(moduleName, moduleHour, thursdayDate);
                    Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                    alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, thursdayAlarm);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                    Toast.makeText(getApplicationContext(), "Session: "+moduleName+" added on "+day.getText().toString(), Toast.LENGTH_SHORT).show();
                    startActivity(alarmIntent);

                }
                if(day.getText().toString().toLowerCase().contentEquals("friday")){
                    String moduleHour = time.getText().toString();
                    String moduleName = module.getText().toString();
                    int hour = Integer.parseInt(moduleHour);
                    db.addEventToDatabase(moduleName, moduleHour, fridayDate);
                    Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
                    alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, 0);
                    alarmIntent.putExtra(AlarmClock.EXTRA_DAYS, fridayAlarm);
                    alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Revision: "+moduleName);
                    Toast.makeText(getApplicationContext(), "Session: "+moduleName+" added on "+day.getText().toString(), Toast.LENGTH_SHORT).show();
                    startActivity(alarmIntent);

                }

            }
            });





    }
}

