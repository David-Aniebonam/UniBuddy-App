package com.example.unibuddyapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

public class helpActivity extends AppCompatActivity {
    private WebView webView;

    //load the help guide webpage

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
        webView = (WebView) findViewById(R.id.guideView) ;
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/UniBuddyWebGuide.html");



    }
    @Override

    //return to previous page
    public void onBackPressed(){
        if(webView.canGoBack()){
            webView.goBack();
        }
        else{
            super.onBackPressed();
        }

    }

}
